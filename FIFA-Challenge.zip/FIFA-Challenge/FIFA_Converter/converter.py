
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def fifa_data_cleaned(df, concat=True):
    num, cat = __fifa_data_cleaning(df)
    num1, cat1 = __fifa_data_convert(num, cat)
    if concat:
        return pd.concat([num1, cat1], axis = 1)
    else:
        return num1, cat1

def __fifa_data_cleaning(df):
    # remove the NaN rows
    df_new = df[(df["Volleys"].isna() == False) & (df["Curve"].isna() == False) & (df["Agility"].isna() == False)]
    # Numerical DataFrame
    df_new_numerical = df_new.select_dtypes(np.number)
    # Categorical Dataframe
    df_new_categorical = df_new.select_dtypes(object)
    #fillna at "Composure"
    mean_composure = df_new_numerical["Composure"].mean()
    df_new_numerical["Composure"] = df_new_numerical["Composure"].fillna(mean_composure)
    #fillna at "Position"
    pos = np.array(["CB", "ST", "GK"])
    list_position_na = list(df_new_categorical[df_new_categorical["Position"].isna() == True].index)
    df_new_categorical.loc[list_position_na,["Position"]] = np.random.choice(pos ,size=len(list_position_na)).reshape((-1,1))
    #fillna at "D/W" fillna at "A/W"
    df_new_categorical[["D/W", "A/W"]] = df_new_categorical[["D/W", "A/W"]].fillna("Medium")
    #fillna at "Club"
    list_club_na = list(df_new_categorical[df_new_categorical["Club"].isna() == True].index)
    df_new_categorical.loc[list_club_na,["Club"]]=np.random.choice(df_new_categorical["Club"],size=len(list_club_na)).reshape((-1,1))
     #dropping "Loan Date End"
    df_new_categorical = df_new_categorical.drop(columns=["Loan Date End"])
    #rename numerical DF
    df_new_numerical= df_new_numerical.rename(columns={
    "PAC":"Pace",
    "SHO":"Shooting",
    "PAS":"Passing",
    "DRI":"Dribbling",
    "DEF":"Defense",
    "PHY":"Physical/Positioning",
    "OVA":"Overall Rating"})
    
    df_new_categorical = df_new_categorical.rename(columns={
    "LCB": "Left Center Back",
    "RCB": "Right Center Back",
    "LB": "Left Back",
    "RB": "Right Back",
    "CM" : "Center Midfield",
    "LDM": "Left Defensive Midfield",
    "LAM": "Left Attacking Midfield",
    "RDM": "Right Defensive Midfield",
    "RAM": "Right Attacking Midfield",
    "CDM": "Center Defensive Midfield",
    "CAM": "Center Attacking Midfield",
    "LM" : "Left Midfield",
    "RM" : "Right Midfield",
    "LW": "Left Winger",
    "RW": "Right Winger",
    "ST": "Striker",
    "CF": "Center Forward",
    "SM": "Skill Moves",
    "BP": "Best Position",
    "IR": "International Reputation",
    "LS": "Long Shots",
    "RS": "Right Striker",
    "LF": "Left Forward",
    "RF": "Right Forward",
    "LCM": "Left Center Midfield",
    "RCM": "Right Center Midfield",
    "LWB": "Left Wing Back",
    "RWB": "Right Wing Back",
    "GK": "Goal Keeper",
    "A/W": "Attacking Workrate",
    "D/W": "Defensing Workrate",
    "W/F": "Weak Foot",
    "CB": "Center Back"})
    
    return df_new_numerical, df_new_categorical

def __fifa_data_convert(def_num, def_cat):
    for column in def_cat.columns:
        def_cat[column] = def_cat[column].apply(__sum_score)
    
    def_cat["Wage"] = def_cat["Wage"].apply(__wage_transform)
    def_cat["Value"] = def_cat["Value"].apply(__wage_transform)
    def_cat["Release Clause"] = def_cat["Release Clause"].apply(__wage_transform)
    
    def_cat["Weak Foot"] = def_cat["Weak Foot"].apply(__star_removal)
    def_cat["Skill Moves"] = def_cat["Skill Moves"].apply(__star_removal)
    def_cat["International Reputation"] = def_cat["International Reputation"].apply(__star_removal)
    
    def_cat["Height"] = def_cat["Height"].apply(__transform_inch_to_cm)
    
    def_cat["Weight"] = def_cat["Weight"].apply(__transform_lbs_to_kg)
    
    def_cat["Hits"] = pd.to_numeric(def_cat["Hits"], errors="coerce")
    def_cat["Hits"] = def_cat["Hits"].fillna(def_cat["Hits"].mean())
    
    def_num = pd.concat([def_num, def_cat.select_dtypes(np.number)], axis = 1)
    def_cat = def_cat.select_dtypes(object)
    
    return def_num, def_cat

def __sum_score(x):
    
    try:
        var = str(x).strip().split("+")
        y = int(var[0])+int(var[1])
        
    except:
        y = x
    return y    

def __transform_inch_to_cm(x):
    #[5, 9"]
    try:
        var = str(x).strip().split("'")

        feet = float(var[0])
        inch = float(var[1].replace("\"", ""))

        cm = feet*30.48 + inch*2.54
    except:
        cm = 0

    return cm    

def __wage_transform(x):
    x = str(x)
    if "K" in x:
        x = x.replace("K", "").replace("€", "")
        y = float(x) * 1000
    elif "M" in x:
        x = x.replace("M", "").replace("€", "")
        y = float(x) * 1000000
    else:
        x = x.replace("€", "")
        y = float(x)
    return y

def __transform_lbs_to_kg(x):
    x = float(str(x).replace("lbs", "").strip())
    
    x = x* 0.453592

    return x

def __star_removal(x):
    x=str(x)
    x = x.replace("★","").strip()
    x = int(x)
    return x

    